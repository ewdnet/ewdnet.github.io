import mongoose from 'mongoose'
const Schema = mongoose.Schema

const ArticleSchema = new Schema({
  title: {
    type: String,
    required: true,
    maxLength: 144,
    minLength: 4,
  },
  cover: {
    type: String,
    required: true,
  },
  body: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
})

const Article = mongoose.model('Article', ArticleSchema)
export default Article
