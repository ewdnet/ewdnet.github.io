const articles = [
  {
    id: 1001,
    title: 'Macarons',
    body: 'Body Macarons Recipie',
    description: 'Recipie Description Macarons'
  },
  {
    id: 1002,
    title: 'Kanafa',
    body: 'Body Kanafa Recipie',
    description: 'Recipie Description Kanafa'
  }
]

export default articles