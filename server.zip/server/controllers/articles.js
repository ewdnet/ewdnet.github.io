import Article from '../models/article.js'

export const postArticle = async (req, res) => {
  try {
    const { title, cover, body, description } = req.body
    const article = await Article.create({ title, cover, body, description })

    await res.json(article)
  } catch (error) {
    res.status(500).send('Error posting article')
  }
}

export const getArticles = async (req, res) => {
  try {
    const articles = await Article.find({})
    await res.json(articles)
  } catch (error) {
    res.status(500).send('Error getting articles')
  }
}

export const getArticleById = async (req, res) => {
  try {
    const { id } = req.params
    const article = await Article.findById(id)
    await res.json(article)
  } catch (error) {
    res.status(500).send('Error getting article')
  }
}
