import express from 'express'
import { postArticle, getArticles, getArticleById } from '../controllers/articles.js'

const router = express.Router()

router.post('/article', postArticle)
router.get('/articles', getArticles)
router.get('/article/:id', getArticleById)

export default router
