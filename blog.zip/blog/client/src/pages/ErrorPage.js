const ErrorPage = () => {
  return (
    <main className="uk-flex-auto uk-section">
      <article className="uk-container uk-container-small">
        <h1>404 - Error Page!</h1>
      </article>
    </main>
  )
}
export default ErrorPage
